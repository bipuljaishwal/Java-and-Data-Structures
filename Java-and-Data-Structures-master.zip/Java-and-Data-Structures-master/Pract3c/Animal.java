package animals;

interface Animal {
   public void eat();
   public void travel();
}
